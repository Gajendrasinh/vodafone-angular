export class User { 
    accountNo: string;
    mobile: string;
      rechargeValue: string;
      isRecurring: boolean = false;
      isTCAccepted: boolean;
      constructor() {
      }
  } 